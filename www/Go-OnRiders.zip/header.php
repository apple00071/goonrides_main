<header class="header header-dark">
		<a href="#" class="nav-btn">
			<span></span>
			<span></span>
			<span></span>
		</a>
		<div class="top-panel">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<marquee behavior="scroll" direction="left" scrollamount="3" onmouseover="this.stop();"
							onmouseout="this.start();">
							<p>*For Super Bike there is Security
								Deposit*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*We Santize Bike After
								Every
								Ride..!!*&nbsp;&nbsp;&nbsp;7777920208</p>
						</marquee>
					</div>
				</div>
			</div>

		</div>
		<div class="container">
			<div class="top-panel-cover">
				<div class="top-panel-left">
					<ul class="header-cont">
						<li><a href="tel:+91 7383838959"><i class="fa fa-phone"></i>+91 7 38 38 38 959</a></li>
						<li><a href="mailto:info@go-onriders.com"><i class="fa fa-envelope"
									aria-hidden="true"></i>info@go-onriders.com</a></li>
					</ul>
				</div>
				<div class="top-panel-center">
					<a href="index" class="logo"><img src="assets/img/rider-logo.png" alt="logo"></a>
				</div>
				<div class="top-panel-right">
					<ul class="icon-right-list">
						<li>
							<a class="header-like" href="https://www.facebook.com/goonriders6" target="_blank"><i
									class="fa fa-facebook" aria-hidden="true"></i></a>
						</li>
						<li>
							<a class="header-user" href="https://twitter.com/home?lang=en" target="_blank"><i
									class="fa fa-twitter" aria-hidden="true"></i></a>
						</li>
						<li>
							<a class="header-cart" href="https://www.instagram.com/go_onriders/" target="_blank"><i
									class="fa fa-instagram" aria-hidden="true"></i></a>
						</li>
						<li>
							<a class="header-cart" href="https://api.whatsapp.com/send?phone=+91 9701659596& text=Hello"
								target="_target"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		</div>
		<div class="header-menu">
			<div class="container">
				<nav class="nav-menu">
					<ul class="nav-list">
						<li class="">
							<a href="index">Home</a>

						</li>
						<li class="">
							<a href="bikes">PRICE LIST </a>

						</li>
						<li><a href="contact">CONTACT US</a></li>

					</ul>
				</nav>
				<!-- <div class="header-two-search d-none d-md-block">
					<div class="header-search-icon"><img src="assets/img/loop-icon.svg" alt=""></div>
					<form class="subscribe-form">
						<i class="fa fa-at" aria-hidden="true"></i>
						<input class="inp-form" type="email" name="subscribe" placeholder="E-mail">
						<button type="submit" class="btn btn-form btn-green"><span>send</span></button>
					</form>
				</div> -->
			</div>
		</div>
	</header>