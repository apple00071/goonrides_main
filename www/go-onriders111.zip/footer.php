<footer class="footer-dark">
		<div class="container">
			<div class="row footer-item-cover">
				<div class="footer-touch col-md-4 col-lg-5">
					<h6 class="orange">stay in touch</h6>
					<ul class="footer-soc social-list">
						<li>
							<a class="header-like" href="https://www.facebook.com/goonriders6" target="_blank"><i
									class="fa fa-facebook" aria-hidden="true"></i></a>
						</li>
						<li>
							<a class="header-user" href="https://twitter.com/home?lang=en" target="_blank"><i
									class="fa fa-twitter" aria-hidden="true"></i></a>
						</li>
						<li>
							<a class="header-cart" href="https://www.instagram.com/go_onriders/" target="_blank"><i
									class="fa fa-instagram" aria-hidden="true"></i></a>
						</li>
						<li>
							<a class="header-cart" href="https://api.whatsapp.com/send?phone=+91 7383838959& text=Hello"
								target="_target"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
						</li>
					</ul>
					<div class="footer-autor">Questions? Please write us at: <a href="mailto:info@go-onredires.com"
							class="white">info@go-onriders.com</a><br>
						<p>Door No:6-2-941,Moghal Emami Mansion,<br>Opp:Shadan College,Khairtabad, <br>Hyderabad,Pin
							Code:500004.</p>
					</div>
				</div>
				<div class="footer-item col-md-4 col-lg-4">
					<h6 class="orange">QUICK LINKS</h6>
					<ul class="footer-list">
						<li><a href="about" class="white">About Us</a></li>
						<li><a href="bikes" class="white">Price List</a></li>
						<li><a href="bikes" class="white">Our Bikes</a></li>
						<li><a href="terms" class="white">Terms & Conditions</a></li>
						<li><a href="contact" class="white">Contact Us</a></li>

					</ul>
				</div>
				<div class="footer-item col-md-3 col-lg-3">
					<h6 class="orange">Connect With Us</h6>
					<h6 class="orange">Call Us</h6>
					<ul class="footer-list">
						<li><a href="tel:+918919936547" class="white">+91 8919 936 547</a></li>
					</ul>
					<h6 class="orange">What's App</h6>
					<ul class="footer-list">
						<li><a class="header-cart" href="https://api.whatsapp.com/send?phone=+91 7383838959& text=Hello"
								target="_target"> 7383838959</a></li>
					</ul>

					</ul>
				</div>
			</div>

			<div class="footer-bottom">
				<div class="footer-copyright"><a class="white" target="_blank" href="#">Go-On Riders</a> © 2020. All Rights Reserved.
				</div>
				<ul class="footer-pay">
					<li><a href="#"><img src="assets/img/footer-pay-1.png" alt="img"></a></li>
					<li><a href="#"><img src="assets/img/footer-pay-2.png" alt="img"></a></li>
					<li><a href="#"><img src="assets/img/footer-pay-3.png" alt="img"></a></li>
					<li><a href="#"><img src="assets/img/footer-pay-4.png" alt="img"></a></li>
				</ul>
			</div>
		</div>
	</footer>